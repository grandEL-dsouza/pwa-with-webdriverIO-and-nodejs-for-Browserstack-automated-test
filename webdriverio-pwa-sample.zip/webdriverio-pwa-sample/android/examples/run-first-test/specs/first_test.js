var assert = require('assert');


describe('Open a PWA app', () => {
  it('abc', async () => {
    
     driver.closeApp();
     driver.activateApp('com.android.chrome');
     driver.setOrientation('PORTRAIT');
     var searchInput = await $('android=new UiSelector().resourceId("com.android.chrome:id/search_box_text")');
     await searchInput.waitForDisplayed({ timeout: 30000 });
     await searchInput.setValue('https://www.myntra.com');
     
     await driver.pressKeyCode(66);

     await browser.pause(5000);

     var menuButton = await $('android=new UiSelector().resourceId("com.android.chrome:id/menu_button")');
     await menuButton.waitForDisplayed({ timeout: 30000 });
     await menuButton.click();

    try {

      var installApp1 = await $('android=new UiSelector().resourceId("com.android.chrome:id/install_webapp_id")');
      await installApp1.waitForDisplayed({ timeout: 30000 });
      if (installApp1) {
        await installApp1.click();
      } else {
        console.log('Element does not exist.');
      }

    }
    catch (error)
    {
      console.error('An error occurred:', error);
    }
     
    try {

      var installApp = await $('android=new UiSelector().resourceId("com.android.chrome:id/add_to_homescreen_id")');
      await installApp.waitForDisplayed({ timeout: 30000 });
      if (installApp) {
        await installApp.click();
      } else {
        console.log('Element does not exist.');
      }

    }
    catch (error)
    {
      console.error('An error occurred:', error);
    }

     await browser.pause(5000);

     var installConfirm = await $('android=new UiSelector().resourceId("com.android.chrome:id/positive_button")');
     await installConfirm.waitForDisplayed({ timeout: 30000 });
     await installConfirm.click();

     await new Promise((resolve) => setTimeout(resolve, 5000))

     var pixelLauncher = await $('/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.LinearLayout/android.widget.Button[2]');
     await pixelLauncher.waitForDisplayed({ timeout: 30000 });
     await pixelLauncher.click();

    await new Promise((resolve) => setTimeout(resolve, 5000))

     driver.terminateApp('com.android.chrome');

     await new Promise((resolve) => setTimeout(resolve, 5000))

     var pixelLauncher = await $('/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.widget.TextView');
     await pixelLauncher.waitForDisplayed({ timeout: 30000 });
     await pixelLauncher.click();

 });

}); 

